# Ghost Bookmarker

A Firefox WebExtension that allows you to bookmark links directly to your Ghost CMS as draft posts.

## Features

- **Context Menu Integration**: Right-click on any link or page to add it to Ghost
- **Keyboard Shortcut**: Press `Ctrl+Shift+P` to bookmark the current tab
- **Popup Interface**: Quick access form to add bookmarks with optional notes
- **CORS Handling**: Automatically sets Origin headers to avoid CORS issues
- **JWT Authentication**: Uses Ghost Admin API with proper JWT signing

## Installation

### Development Installation

1. **Load the extension in Firefox**:
   - Open Firefox and navigate to `about:debugging`
   - Click "This Firefox" in the left sidebar
   - Click "Load Temporary Add-on..."
   - Select the `manifest.json` file from this directory

2. **Configure your Ghost API**:
   - Click the extension icon in Firefox toolbar
   - Click "Settings" button
   - Enter your Ghost Admin API URL and API Key
   - Click "Test Connection" to verify
   - Click "Save Settings"

### Getting Your Ghost Admin API Key

1. Go to your Ghost Admin dashboard
2. Navigate to **Settings → Integrations**
3. Click **"Add custom integration"**
4. Copy the **Admin API key** (format: `keyId:secret`)
5. Paste it in the extension settings

## Project Structure

```
ghostbookmark/
├── manifest.json          # Extension manifest (Manifest V2)
├── background.js          # Background script (context menus, commands, webRequest)
├── popup.html            # Popup interface
├── popup.css             # Popup styles
├── popup.js              # Popup logic
├── options.html          # Settings page
├── options.css           # Settings page styles
├── options.js            # Settings page logic
├── utils.js              # Utility functions (JWT signing, validation)
├── icons/                # Extension icons
│   ├── icon-16.png
│   ├── icon-48.png
│   └── icon-128.png
└── README.md             # This file
```

## Usage

### Adding a Bookmark via Context Menu

1. Right-click on any link or page
2. Select "Add bookmark to Ghost"
3. The popup will open with the URL pre-filled
4. Optionally add a note
5. Click "Save to Ghost"

### Adding a Bookmark via Keyboard Shortcut

1. Navigate to the page you want to bookmark
2. Select any text on the page (optional, becomes the note)
3. Press `Ctrl+Shift+P`
4. The popup will open with the current URL and selected text
5. Click "Save to Ghost"

### Adding a Bookmark via Popup

1. Click the extension icon in the toolbar
2. The current tab's URL will be pre-filled
3. Optionally edit the URL or add a note
4. Click "Save to Ghost"

## How It Works

The extension creates or updates a draft post in your Ghost site titled "Bookmarked links". Each bookmark is added as a new paragraph with:

- The bookmark URL as a clickable link
- Optional note text
- Timestamp of when it was added

All bookmarks are stored in a single draft post, making it easy to review and organize them later in Ghost.

## Technical Details

### Manifest V2

This extension uses Manifest V2 and the `browser.*` namespace as required by Firefox.

### Permissions

- `storage`: Save user settings and temporary data
- `contextMenus`: Add context menu items
- `tabs`: Access current tab information
- `webRequest` & `webRequestBlocking`: Modify request headers for CORS
- `notifications`: Show success/error messages
- `activeTab`: Access active tab content
- Host permissions for Ghost domains

### Custom Ghost Origins

The manifest includes permissions for standard Ghost domains (`*.ghost.io`, `*.ghost.org`, `*.ghost.is`). If you're using a self-hosted Ghost instance or a custom domain, you'll need to:

1. Edit `manifest.json`
2. Add your custom domain to the `permissions` array, e.g.:
   ```json
   "permissions": [
     ...
     "https://your-custom-domain.com/*"
   ]
   ```
3. Reload the extension in Firefox

Note: Manifest V2 doesn't support runtime permission requests, so custom domains must be declared in the manifest.

### JWT Authentication

The extension uses JWT tokens signed with HMAC-SHA256 to authenticate with Ghost Admin API. Tokens are generated on-demand with a 5-minute expiry.

### CORS Handling

The `webRequest.onBeforeSendHeaders` listener intercepts requests to Ghost domains and sets the `Origin` header to match your Ghost site, preventing CORS issues.

## Building

No build process is required. The extension works directly from source files. However, note that:

- `utils.js` contains utility functions that are duplicated in `background.js` and `options.js` since ES modules aren't available in Manifest V2 background scripts
- All files must be included in the extension package

### Optional: Create Icon Files

You'll need to create icon files in the `icons/` directory:
- `icon-16.png` (16x16 pixels)
- `icon-48.png` (48x48 pixels)
- `icon-128.png` (128x128 pixels)

You can use any image editor or online tool to create these icons. A simple bookmark or Ghost-themed icon would work well.

### Packaging for Distribution

To create a distributable package:

```bash
# Create a zip file (excluding development files)
zip -r ghostbookmark.zip . -x "*.git*" -x "*.md" -x "*.zip"
```

Then you can submit it to Firefox Add-ons (AMO) or distribute it manually.

## Development

### Testing

1. Load the extension in Firefox using `about:debugging`
2. Open the browser console to see any errors
3. Test all features:
   - Context menu on links and pages
   - Keyboard shortcut
   - Popup form
   - Settings page
   - API connection

### Debugging

- **Background Script**: Open `about:debugging`, find your extension, click "Inspect"
- **Popup**: Right-click the extension icon, select "Inspect Popup"
- **Options Page**: Right-click on the options page, select "Inspect Element"

## Troubleshooting

### "Ghost API settings not configured"

- Go to Settings (click extension icon → Settings button)
- Enter your Ghost Admin API URL and API Key
- Click "Test Connection" to verify it works
- Save the settings

### "Failed to save bookmark"

- Check that your Ghost API key is correct (format: `keyId:secret`)
- Verify your Ghost URL is accessible
- Check the browser console for detailed error messages
- Try the "Test Connection" button in settings

### CORS Errors

- The extension should automatically handle CORS by setting Origin headers
- If you still see CORS errors, check that your Ghost URL in settings is correct
- Ensure the webRequest listener is working (check background script console)

## License

MIT License - feel free to modify and distribute as needed.

## Contributing

This is a starter project. Feel free to enhance it with:
- Better error handling
- Batch bookmark operations
- Custom post templates
- Tag support
- Search functionality
- etc.

